
/* =====================================================================
   TEP - Base de Datos Relacional (SQL Server) Proyecto de titulo
   ===================================================================== */
/* ============================================================== BASE DE DATOS =============================================================================*/
IF DB_ID(N'TEP') IS NULL
BEGIN
  CREATE DATABASE TEP;
END
GO
USE TEP;
GO

/* ================================================================ TABLAS ================================================================================== */
/* === Regi�n === */
IF OBJECT_ID(N'dbo.Region','U') IS NULL
CREATE TABLE dbo.Region(
    RegionId INT IDENTITY(1,1) PRIMARY KEY,
    Nombre   NVARCHAR(100) NOT NULL UNIQUE
);
GO

/* === Localidad (asociada a Regi�n, con columnas solicitadas) === */
IF OBJECT_ID(N'dbo.Localidad','U') IS NULL
CREATE TABLE dbo.Localidad(
    LocalidadId     INT IDENTITY(1,1) PRIMARY KEY,
    RegionId        INT NOT NULL,
    NombreRegion    NVARCHAR(100) NOT NULL,    -- redundante para reportes/carga masiva
    ComunaID        NVARCHAR(10)  NOT NULL,    -- c�digo interno de ciudad
    NombreCiudad    NVARCHAR(100) NOT NULL,    -- nombre de la ciudad/localidad
    CodigoComunaID  NVARCHAR(10)  NULL,        -- c�digo alterno (ej. 'PUD')
    CONSTRAINT FK_Localidad_Region FOREIGN KEY (RegionId) REFERENCES dbo.Region(RegionId),
    CONSTRAINT UQ_Localidad UNIQUE(RegionId, ComunaID)
);
GO

/* === Organizaci�n === */
IF OBJECT_ID(N'dbo.Empresa','U') IS NULL
CREATE TABLE dbo.Empresa(
    EmpresaId   INT IDENTITY(1,1) PRIMARY KEY,
    RazonSocial NVARCHAR(150) NOT NULL,
    Rut         NVARCHAR(20) NULL,
    Activa      BIT NOT NULL DEFAULT 1,
    CreadaEn    DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

IF OBJECT_ID(N'dbo.Tienda','U') IS NULL
CREATE TABLE dbo.Tienda(
    TiendaId   INT IDENTITY(1,1) PRIMARY KEY,
    EmpresaId  INT NOT NULL,
    Nombre     NVARCHAR(150) NOT NULL,
	Direccion  NVARCHAR(200) NOT NULL,
	RegionId   INT NOT NULL,
	LocalidadId INT NOT NULL,
    Activa     BIT NOT NULL DEFAULT 1,
    CreadaEn   DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Tienda_Empresa FOREIGN KEY (EmpresaId) REFERENCES dbo.Empresa(EmpresaId),
	CONSTRAINT FK_Tienda_Region FOREIGN KEY (RegionId) REFERENCES dbo.Region(RegionId),
	CONSTRAINT FK_Tienda_Localidad FOREIGN KEY (LocalidadId) REFERENCES dbo.Localidad(LocalidadId),
    CONSTRAINT UQ_Tienda UNIQUE(EmpresaId, Nombre)
);
GO

/* === Seguridad === */
IF OBJECT_ID(N'dbo.Rol','U') IS NULL
CREATE TABLE dbo.Rol(
    RolId  INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(50) NOT NULL UNIQUE
);
GO

IF OBJECT_ID(N'dbo.Usuario','U') IS NULL
CREATE TABLE dbo.Usuario(
    UsuarioId    INT IDENTITY(1,1) PRIMARY KEY,
    EmpresaId    INT NULL,
    RolId        INT NOT NULL,
    Nombre       NVARCHAR(100) NOT NULL,
    Apellido     NVARCHAR(100) NOT NULL,
    Email        NVARCHAR(200) NOT NULL UNIQUE,
    Clave        VARBINARY(256) NOT NULL,
    Activo       BIT NOT NULL DEFAULT 0,
    CreadoEn     DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Usuario_Rol FOREIGN KEY (RolId) REFERENCES dbo.Rol(RolId),
    CONSTRAINT FK_Usuario_Empresa FOREIGN KEY (EmpresaId) REFERENCES dbo.Empresa(EmpresaId)
);
GO

IF OBJECT_ID('dbo.RecuperacionClave','U') IS NULL
BEGIN
    CREATE TABLE dbo.RecuperacionClave(
        TokenId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
        UsuarioId INT NOT NULL,
        Token NVARCHAR(200) NOT NULL,        -- token seguro (random url-safe)
        ExpiraEn DATETIME2(0) NOT NULL,      -- p.ej. ahora + 60 min
        Usado BIT NOT NULL DEFAULT 0,
        CreadoEn DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_Clave_Usuario FOREIGN KEY (UsuarioId) REFERENCES dbo.Usuario(UsuarioId),
        CONSTRAINT UQ_RecClave_Token UNIQUE(Token)
    );
END
GO

/* === Orden de Venta === */
IF OBJECT_ID(N'dbo.Venta','U') IS NULL
CREATE TABLE dbo.Venta(
    OrdenVentaId     INT IDENTITY(1,1) PRIMARY KEY,
    TiendaId         INT NOT NULL,
/*	=== DATOS DE CLIENTE === */
    NombreCliente    NVARCHAR(100) NOT NULL,
    ApellidoCliente  NVARCHAR(100) NOT NULL,
    RutCliente       NVARCHAR(20)  NULL,
    TelefonoCliente  NVARCHAR(30)  NULL,
    CorreoCliente    NVARCHAR(150) NULL,
    DireccionCliente NVARCHAR(200) NOT NULL,
	ReferenciaCliente NVARCHAR(200) NULL,
    RegionId         INT NULL,
    LocalidadId      INT NULL,   
    NumeroOrdenVenta NVARCHAR(100) NOT NULL,
    NumeroBoleta     NVARCHAR(100) NULL,
    ValorTotal       DECIMAL(18,2) NOT NULL,
	Cantidad		 INT NOT NULL,
    Bultos           INT NOT NULL DEFAULT 1,
    SKU              NVARCHAR(100) NOT NULL,
    Descripcion      NVARCHAR(300) NULL,
    FechaVenta       DATETIME2(0) NOT NULL,
    FechaRecepcion   DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
    Cobertura        BIT NULL,
    CONSTRAINT UQ_OV_Tienda_Orden UNIQUE(TiendaId, NumeroOrdenVenta),
	CONSTRAINT FK_Cliente_Region    FOREIGN KEY (RegionId)    REFERENCES dbo.Region(RegionId),
    CONSTRAINT FK_Cliente_Localidad FOREIGN KEY (LocalidadId) REFERENCES dbo.Localidad(LocalidadId),
    CONSTRAINT FK_OV_Tienda  FOREIGN KEY (TiendaId)  REFERENCES dbo.Tienda(TiendaId)
);
GO

/* === Etiqueta === */
IF OBJECT_ID(N'dbo.Etiqueta','U') IS NULL
CREATE TABLE dbo.Etiqueta(
    EtiquetaId   INT IDENTITY(1,1) PRIMARY KEY,
    OrdenVentaId INT NOT NULL,
    Formato      NVARCHAR(10) NOT NULL DEFAULT N'PDF',
    Contenido    VARBINARY(MAX) NOT NULL,
    CreadaEn     DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Etiqueta_OV FOREIGN KEY (OrdenVentaId) REFERENCES dbo.Venta(OrdenVentaId)
);
GO

-- Cat�logo de couriers
IF OBJECT_ID(N'dbo.Transporte','U') IS NULL
BEGIN
    CREATE TABLE dbo.Transporte(
        CourrierId    INT IDENTITY(1,1) CONSTRAINT PK_Courrier PRIMARY KEY,
        Nombre        NVARCHAR(120) NOT NULL UNIQUE,  -- p.ej. 'Blue Express'
        EndpointBase  NVARCHAR(300) NULL,             -- URL base del API del courier
        Activo        BIT NOT NULL CONSTRAINT DF_Courrier_Activo DEFAULT(1),
        CreadoEn      DATETIME2(0) NOT NULL CONSTRAINT DF_Courrier_Creado DEFAULT SYSUTCDATETIME()
    );
END
GO

/* === Inyecci�n === */
IF OBJECT_ID(N'dbo.Inyeccion','U') IS NULL
CREATE TABLE dbo.Inyeccion (
    InyeccionId       INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Inyeccion PRIMARY KEY,
    OrdenVentaId      INT NOT NULL,
    EtiquetaId        INT NULL,
    SKU               NVARCHAR(100) NOT NULL,
    OT                NVARCHAR(50)  NOT NULL,
    CourrierId        INT NULL,
    Reinyeccion       BIT NOT NULL CONSTRAINT DF_Inyeccion_Reinyeccion DEFAULT(0),
    FechaReinyeccion  DATETIME2(0) NULL,
    FechaInyeccion    DATETIME2(0) NOT NULL CONSTRAINT DF_Inyeccion_FechaInyeccion DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Inyeccion_OrdenVenta FOREIGN KEY (OrdenVentaId) REFERENCES dbo.Venta(OrdenVentaId),
    CONSTRAINT FK_Inyeccion_Etiqueta   FOREIGN KEY (EtiquetaId)  REFERENCES dbo.Etiqueta(EtiquetaId),
	CONSTRAINT FK_Inyeccion_Courrier   FOREIGN KEY (CourrierId)  REFERENCES dbo.Transporte(CourrierId)
);
GO

-- Credenciales por courier (y por empresa si aplica multi-tenant)
IF OBJECT_ID(N'dbo.CredencialesTransporte','U') IS NULL
CREATE TABLE dbo.CredencialesTransporte(
    CredencialId     INT IDENTITY(1,1) CONSTRAINT PK_CourrierCred PRIMARY KEY,
    CourrierId       INT NOT NULL,
    TOKEN         NVARCHAR(200) NULL,
    USERCODE      NVARCHAR(50) NULL,
    CLIENT_ACCOUNT NVARCHAR(50) NULL,
    UserName         NVARCHAR(100) NULL,
    Clave            NVARCHAR(200) NULL,
    EndpointOverride NVARCHAR(300) NULL,          -- opcional: endpoint espec�fico para esta credencial
    EsProduccion     BIT NOT NULL CONSTRAINT DF_CourrierCred_Prod DEFAULT(1),
    Activa           BIT NOT NULL CONSTRAINT DF_CourrierCred_Activa DEFAULT(1),
    CreadaEn         DATETIME2(0) NOT NULL CONSTRAINT DF_CourrierCred_Creada DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_CourrierCred_Courrier FOREIGN KEY (CourrierId) REFERENCES dbo.Transporte(CourrierId)
    -- Si tienes dbo.Empresa: CONSTRAINT FK_CourrierCred_Empresa FOREIGN KEY (EmpresaId) REFERENCES dbo.Empresa(EmpresaId)
);
GO

/* === Estados del Carrier (se mantiene igual, campos de texto para nombres/c�digos) === */
IF OBJECT_ID(N'dbo.Estados','U') IS NULL
CREATE TABLE dbo.Estados(
    Id            INT IDENTITY(1,1) PRIMARY KEY,
    EstatusDesc   NVARCHAR(255) NOT NULL,   -- Descripci�n del estado recibido (ej: GUIA ENVIADA, EN RUTA, ENTREGADO)
    FechaEstatus  DATE NOT NULL,           -- Fecha del estado
    HoraEstatus   TIME NOT NULL,            -- Hora del estado
    OT            NVARCHAR(50) NOT NULL,             -- N�mero de orden de transporte / gu�a
    Motivo        NVARCHAR(255) NULL,            -- Observaci�n o motivo (ej: rechazo, entrega fallida)
    IdUsuario     INT NULL,                   -- Usuario que registr� (FK a Usuario si aplica)
    FechaCarga    DATETIME DEFAULT GETDATE(), -- Momento en que se insert� el estado en BD
	InyeccionId   INT NOT NULL
    CONSTRAINT FK_Estados_OV FOREIGN KEY (InyeccionId) REFERENCES dbo.Inyeccion(InyeccionId)
);
GO

/* ================================================================== �NDICES ================================================================================= */
/* === Localidad =========================================== */
/* B�squedas por Region y Ciudad */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Localidad_RegionId')
    CREATE INDEX IX_Localidad_RegionId ON dbo.Localidad(RegionId);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Localidad_Ciudad')
    CREATE INDEX IX_Localidad_Ciudad ON dbo.Localidad(ComunaID, NombreCiudad);


/* === Empresa ============================================= */
/* Listados/joins */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Empresa_Activa')
    CREATE INDEX IX_Empresa_Activa ON dbo.Empresa(Activa) INCLUDE (RazonSocial, CreadaEn);


/* === Tienda ============================================== */
/* Join por Empresa, filtros por Activa */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Tienda_EmpresaId')
    CREATE INDEX IX_Tienda_EmpresaId ON dbo.Tienda(EmpresaId);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Tienda_Activa')
    CREATE INDEX IX_Tienda_Activa ON dbo.Tienda(Activa) INCLUDE (EmpresaId, Nombre);


/* === Usuario ============================================= */
/* Login por Email y listados por Empresa/Rol/Activo */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Usuario_Email')
    CREATE UNIQUE INDEX IX_Usuario_Email ON dbo.Usuario(Email);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Usuario_Empresa')
    CREATE INDEX IX_Usuario_Empresa ON dbo.Usuario(EmpresaId) INCLUDE (RolId, Activo, Email, Nombre, Apellido);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Usuario_Rol')
    CREATE INDEX IX_Usuario_Rol ON dbo.Usuario(RolId) INCLUDE (EmpresaId, Activo);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Usuario_Activo')
    CREATE INDEX IX_Usuario_Activo ON dbo.Usuario(Activo) INCLUDE (EmpresaId, RolId, Email);


/* === RecuperacionClave =================================== */
/* B�squeda por token, limpieza por expiraci�n/uso */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_RecClave_Token')
    CREATE UNIQUE INDEX IX_RecClave_Token ON dbo.RecuperacionClave(Token);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_RecClave_Expira_Usado')
    CREATE INDEX IX_RecClave_Expira_Usado ON dbo.RecuperacionClave(Usado, ExpiraEn) INCLUDE (UsuarioId);


/* === OrdenVenta ========================================== */
/* Joins y reportes: por Tienda, fechas, SKU, Regi�n/Localidad, b�squeda por N�mero */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_OV_Tienda')
    CREATE INDEX IX_OV_Tienda ON dbo.Venta(TiendaId);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_OV_Fechas')
    CREATE INDEX IX_OV_Fechas ON dbo.Venta(FechaVenta, FechaRecepcion) INCLUDE (TiendaId, ValorTotal, SKU, Bultos, Cantidad);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_OV_SKU')
    CREATE INDEX IX_OV_SKU ON dbo.Venta(SKU) INCLUDE (TiendaId, FechaVenta, ValorTotal);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_OV_Region_Localidad')
    CREATE INDEX IX_OV_Region_Localidad ON dbo.Venta(RegionId, LocalidadId);


/* === Etiqueta ============================================ */
/* Joins desde OV y consultas recientes */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Etiqueta_OV')
    CREATE INDEX IX_Etiqueta_OV ON dbo.Etiqueta(OrdenVentaId) INCLUDE (Formato, CreadaEn);


/* === Transporte (Courrier) ================================ */
/* Listados por Activo */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Transporte_Activo')
    CREATE INDEX IX_Transporte_Activo ON dbo.Transporte(Activo) INCLUDE (Nombre);


/* === Inyeccion =========================================== */
/* B�squeda por OV, por OT y por courier; auditor�a por fechas */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Iny_OV')
    CREATE INDEX IX_Iny_OV ON dbo.Inyeccion(OrdenVentaId) INCLUDE (OT, SKU, FechaInyeccion);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Iny_OT')
    CREATE INDEX IX_Iny_OT ON dbo.Inyeccion(OT);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Iny_Courrier')
    CREATE INDEX IX_Iny_Courrier ON dbo.Inyeccion(CourrierId) INCLUDE (OT, FechaInyeccion);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Iny_Fecha')
    CREATE INDEX IX_Iny_Fecha ON dbo.Inyeccion(FechaInyeccion DESC) INCLUDE (OrdenVentaId, OT);


/* === CredencialesTransporte =============================== */
/* Una activa por courier (siempre hay que ir a buscar la vigente) */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CredTrans_Courrier')
    CREATE INDEX IX_CredTrans_Courrier ON dbo.CredencialesTransporte(CourrierId) INCLUDE (Activa, EsProduccion);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CredTrans_Activa_Filter')
    CREATE UNIQUE INDEX IX_CredTrans_Activa_Filter
        ON dbo.CredencialesTransporte(CourrierId)
        WHERE Activa = 1 AND EsProduccion = 1;  -- asegura m�ximo 1 credencial activa/prod por courier


/* === Estados ============================================== */
/* B�squeda por Inyecci�n y por OT (tracking) */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Estados_Inyeccion')
    CREATE INDEX IX_Estados_Inyeccion ON dbo.Estados(InyeccionId, FechaEstatus, HoraEstatus);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Estados_OT')
    CREATE INDEX IX_Estados_OT ON dbo.Estados(OT, FechaEstatus, HoraEstatus) INCLUDE (EstatusDesc, Motivo);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Estados_Usuario')
    CREATE INDEX IX_Estados_Usuario ON dbo.Estados(IdUsuario) INCLUDE (OT, FechaEstatus, HoraEstatus);
GO

/* ============================================================= LLENADO TABLAS ========================================================================= */
/* === Semillas m�nimas === */
IF NOT EXISTS(SELECT 1 FROM dbo.Rol)
BEGIN
    INSERT INTO dbo.Rol(Nombre) VALUES (N'SuperUsuario'),(N'Administrador'),(N'Administrativo');
END
GO
